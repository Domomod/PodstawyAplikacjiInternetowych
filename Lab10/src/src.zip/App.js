import React from 'react';
import ToDoList from './ToDoList';
import NewTask from './NewTask';
import Filter from './Filter';

class App extends React.Component{
constructor() {
    super()
    this.state = {
        tasks: [],
        filter: false,
    }
    this.handleChange = this.handleChange.bind(this)
    this.handleFilter = this.handleFilter.bind(this)
    this.handlePush   = this.handlePush.bind(this)
  }

  handleFilter(){
    this.setState(prevState =>{
        return {
            ...prevState,
            filter: !prevState.filter,
        }
    })
  }

  handlePush(task){
    this.setState(prevState =>{
        return {
            ...prevState,
            tasks: [...prevState.tasks, task],
        }
    })
  }

  handleChange(id) {
    this.setState(prevState =>{
        const newTasks = prevState.tasks.map( task => {
                if (task.id === id) {
                    return {
                        ...task,
                        completed: !task.completed
                    }
                }
                return task
            }
        )
        return {
            ...prevState,
            tasks: newTasks,
        }
    })
  }

  render(){
      return(
        <div className="main-container">
          <Filter handleFilter={this.handleFilter}/>
          <ToDoList tasks={this.state.tasks} handleChange={this.handleChange} filterOn={this.state.filter}/>
          <NewTask handlePush={this.handlePush}/>
        </div>
      )
    }
}
  
export default App;
