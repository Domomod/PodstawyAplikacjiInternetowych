import React from 'react';

const Filter = (props) =>
            <div className="underlined">
                <input
                    type="checkbox"
                    onChange={() => props.handleFilter()}
                />
                hide completed
            </div>

export default Filter;
